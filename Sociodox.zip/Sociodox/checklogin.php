<?php
	//Checking of login By Aditya
	if($_SERVER["REQUEST_METHOD"] == "POST"){
	session_start();
	require_once("database.php"); 
	$pass = $_POST["password"];
	$email = $_POST["email_phone"];
	echo "$email";

	$sql = "SELECT * from users WHERE email='$email'"; 
	$query = mysqli_query($conn, $sql);
	$exists = mysqli_num_rows($query); 
	echo "$exists";
	$table_users = "";
	$table_password = "";
	if($exists > 0) 
	{
		while($row = mysqli_fetch_assoc($query)) 
		{
			$table_users = $row['email']; 
			$table_password = $row['password'];
		}
		if(($email == $table_users) && ($pass == $table_password))
		{
				if($pass == $table_password)
				{
					$_SESSION['email'] = $email; 
					header("location: #"); 
				}
				
		}
		else
		{
			Print '<script>alert("Incorrect Password!");</script>'; 
			Print '<script>window.location.assign("index.html");</script>'; 
		}

	}
	else
	{
		Print '<script>alert("Invalid email or phone number!");</script>'; 
		Print '<script>window.location.assign("index.html");</script>'; 
	}

	mysqli_close($conn);
}
?>
