<?php

//Sign Up Aditya
if($_SERVER["REQUEST_METHOD"] == "POST"){
require_once("database.php"); 
$user = $_POST["username"];
$pass = $_POST["password"];
$email = $_POST["email_phone"];

    $bool = true;

	$sql = "Select * from users"; //Query the users table
	$query = mysqli_query($conn, $sql);
	while($row = mysqli_fetch_assoc($query)) //display all rows from query
	{
		$table_users = $row['username']; // the first username row is passed on to $table_users, and so on until the query is finished
		if($user == $table_users) // checks if there are any matching fields
		{
			$bool = false; // sets bool to false
			Print '<script>alert("Username has been taken!");</script>'; //Prompts the user
			Print '<script>window.location.assign("index.html");</script>'; // redirects to index.html
		}
	}

	if($bool) // checks if bool is true
	{
		$sql1 = "INSERT INTO users(username,email,password) VALUES('$user','$email', '$pass')";
		$result = mysqli_query($conn,$sql1) or die("could");
		if($result){
			Print '<script>alert("Successfully Registered! Please Login ");</script>'; // Prompts the user
		    Print '<script>window.location.assign("index.html");</script>'; // redirects to index.html
            }
		 else {
			 echo "error";
		 }
		

    }
  }

?>