drop table if EXISTS donation;
drop table if EXISTS contact;
drop table if EXISTS users;

create table users(username varchar(50) primary key,email varchar(100),mobile_no int(20),password varchar(100) not null);

create table contact(contact_id INT primary key,first_name varchar(50) not null,last_name varchar(50) not null,email varchar(100) not null,mobile_no int(20) not null,msg text(500) );

create table donation(donation_id INT primary key,first_name varchar(50) not null,last_name varchar(50) not null,email varchar(100) not null,mobile_no int(20) not null,amount_status varchar(50),amount int(30) not null,comment text(50));

