<?php

$server = 'localhost';
$user = 'root';
$password = '' ;
$db = 'sociodox';

$conn = mysqli_connect($server,$user,$password,$db);

if($conn){
    echo "connection successful";
}
else{
    echo " Error : -" .mysqli_connect_error();
}

?>